# ProGuard rules for CalculatorApp
-keep public class * {
    public protected *;
}
-keepclassmembers class * {
    public protected *;
}

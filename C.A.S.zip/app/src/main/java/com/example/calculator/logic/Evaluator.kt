package com.example.calculator.logic

import org.mariuszgromada.math.mxparser.Expression

class Evaluator {

    companion object {
        const val ERROR_INVALID_EXPRESSION = "Error"
        const val ERROR_DIVISION_BY_ZERO = "Cannot divide by zero"
    }

    fun evaluate(expression: String): String {
        val cleanExpression = expression
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")

        return try {
            val exp = Expression(cleanExpression)
            val result = exp.calculate()

            if (result.isNaN() || result.isInfinite()) {
                ERROR_INVALID_EXPRESSION
            } else {
                if (result == result.toLong().toDouble()) {
                    result.toLong().toString()
                } else {
                    String.format("%.8f", result).trimEnd('0').trimEnd('.')
                }
            }
        } catch (e: Exception) {
            ERROR_INVALID_EXPRESSION
        }
    }

    fun isValidExpression(expression: String): Boolean {
        if (expression.isEmpty()) return false
        val lastChar = expression.last()
        return lastChar.isDigit() || lastChar == ')'
    }
}
